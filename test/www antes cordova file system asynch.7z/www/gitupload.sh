git status
git add .
git commit -m "Uploading Whopaid"
git push origin
