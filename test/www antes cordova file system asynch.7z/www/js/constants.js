var C_VIEW_MODE_NOT_SET = 0;
var C_VIEW_MODE_EDITION = 1;
var C_VIEW_MODE_NEW = 2;

var C_VIEW_PAGE_ID_SPLASH = "splashView";
var C_VIEW_PAGE_ID_MENU = "menuView";
var C_VIEW_PAGE_ID_ABOUT = "aboutView";
var C_VIEW_PAGE_ID_SPENT = "spentView";
var C_VIEW_PAGE_ID_MAIN = "mainView";
var C_VIEW_PAGE_ID_MAIN_CONTENT = "mainViewContent";
var C_VIEW_PAGE_ID_SPENT_LIST = "spentListView";
var C_VIEW_PAGE_ID_TEST = "testView";
var C_VIEW_PAGE_ID_LOGIN = "loginView";
var C_VIEW_PAGE_ID_SPLASH = "splashView";
var C_VIEW_PAGE_ID_WIDGET = "widgetView";