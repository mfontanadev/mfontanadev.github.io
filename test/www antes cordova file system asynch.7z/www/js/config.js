function Config() {}

Config.C_FOLDER_VIEWS = "views/";
Config.C_LOG = true;
Config.C_ANDROID_DEFINED = 0;
Config.C_DELAY_INSERT_RECORD_MS = 100;   // in miliseconds
Config.DEBUG = true;