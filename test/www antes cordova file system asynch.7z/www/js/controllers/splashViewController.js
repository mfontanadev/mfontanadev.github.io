SplashViewController._this = null;

function SplashViewController() 
{
  SplashViewController._this = this;
}

SplashViewController.prototype.init = function()
{
  this.setPageTitle();
}

SplashViewController.prototype.setPageTitle = function() 
{
}
